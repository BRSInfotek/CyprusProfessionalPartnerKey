package org.cyprus.mrp.server.window;

//import com.compiere.client.SysEnv;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Level;
//import org.compiere.common.QueryRestrictionVO;
//import org.compiere.common.QueryVO;
//import org.compiere.controller.GridFieldVO;
//import org.compiere.framework.Lookup;
//import org.compiere.gwt.server.ConvertUIVO;
//import org.compiere.gwt.server.ReportServiceHelper;
//import org.compiere.gwt.server.Util;
//import org.compiere.gwt.server.component.InfoComponentImpl;
//import org.compiere.gwt.server.component.SearchComponentImpl;
//import org.compiere.gwt.server.component.TableComponentImpl;
//import org.compiere.gwt.server.window.WindowImpl;
//import org.compiere.intf.ComponentImplIntf;
//import org.compiere.intf.WindowImplIntf;
import org.compiere.model.GridField;
import org.compiere.model.GridFieldVO;
import org.compiere.model.MLookup;
import org.compiere.model.MLookupFactory;
import org.compiere.model.MLookupInfo;
import org.compiere.util.CLogger;
import org.compiere.util.CPreparedStatement;
//import org.compiere.util.Ctx;
import org.compiere.util.DB;
import org.compiere.util.Env;
import org.compiere.util.Msg;
import org.compiere.util.NamePair;
//import org.compiere.util.QueryUtil;
import org.compiere.util.Trx;
import org.compiere.util.Util;
import org.compiere.util.ValueNamePair;
import org.cyprus.common.QueryRestrictionVO;
import org.cyprus.common.QueryVO;
import org.cyprus.intf.ComponentImplIntf;
import org.cyprus.intf.WindowImplIntf;
import org.cyprus.util.QueryUtil;
import org.cyprus.vos.ChangeVO;
import org.cyprus.vos.FieldVO;
import org.cyprus.vos.ListBoxVO;
import org.cyprus.vos.ProcessInfoVO;
import org.cyprus.vos.UWindowID;
//import org.compiere.vos.ChangeVO;
//import org.compiere.vos.FieldVO;
//import org.compiere.vos.ListBoxVO;
//import org.compiere.vos.ProcessInfoVO;
//import org.compiere.vos.UWindowID;
//import org.compiere.vos.WindowCtx;
//import org.compiere.vos.WindowVO;
import org.cyprus.vos.WindowCtx;
import org.cyprus.vos.WindowVO;

public class ImplementPlanWindowImpl extends WindowImpl {
  private static CLogger s_log = CLogger.getCLogger(ImplementPlanWindowImpl.class);
  
  final String m_AD_User_ID;
  
  final SearchComponentImpl c_search;
  
  final InfoComponentImpl c_info;
  
  final SearchComponentImpl c_process;
  
  protected ArrayList<ComponentImplIntf> components = new ArrayList<ComponentImplIntf>();
  
  protected final Properties serverCtx;
  
  protected final WindowCtx windowCtx;
  
  protected final UWindowID m_uid;
  
  protected final int windowNO;
  
  
  public ImplementPlanWindowImpl(int windowNO, Properties serverCtx, WindowCtx windowCtx, UWindowID uid) {
    this.serverCtx = serverCtx;
    this.windowCtx = windowCtx;
    this.m_uid = uid;
    this.windowNO = windowNO;
  //  this.m_AD_User_ID = Integer.toString(serverCtx.getAD_User_ID());
    this.m_AD_User_ID = Integer.toString(Env.getAD_User_ID(serverCtx));
    this.c_info = new InfoComponentImpl(serverCtx, 128, true, false) {
        protected QueryVO processQueryVO(QueryVO p_queryVO, WindowCtx windowCtx) {
          QueryVO b = TableComponentImpl.buildQueryVO(windowCtx, this.componentVO.fieldVOs);
          TableComponentImpl.convertColumnNameToSelectClause(p_queryVO, this.componentVO.fieldVOs);
          int MRP_Plan_ID = ((BigDecimal)ImplementPlanWindowImpl.this.c_search.getFieldValue(windowCtx, "MRP_Plan_ID")).intValue();
          if (MRP_Plan_ID != 0)
            b.restrictions.add(new QueryRestrictionVO("pl.MRP_Plan_ID", "=", Integer.toString(MRP_Plan_ID), null, null, (ImplementPlanWindowImpl.this.c_search.getComponentVO().getFieldVO("MRP_Plan_ID")).displayType)); 
          b.addRestrictions(p_queryVO);
          return b;
        }
      };
    ArrayList<FieldVO> fieldVOs = (this.c_info.getComponentVO()).fieldVOs;
    ArrayList<FieldVO> searchFields = new ArrayList<FieldVO>();
    FieldVO f_plan = Util.createFieldVO(serverCtx, "MRP_Plan_ID", Msg.translate(serverCtx, "MRP_Plan_ID"), 19);
    f_plan.ColumnSQL = "pl.MRP_Plan_ID";
    f_plan.IsMandatoryUI = true;
    f_plan.isImpactsValue = true;
    String planActiveValidation = "MRP_Plan.IsActive='Y'";
    MLookup lookupPlan = MLookupFactory.get(serverCtx, 0, 28017, 19, Env.getLanguage(serverCtx), "MRP_Plan_ID", 0, false, planActiveValidation);
    GridFieldVO gfvo = new GridFieldVO(serverCtx, f_plan);
    GridField mField = new GridField(gfvo);
    mField.loadLookup();
    mField.lookupLoadComplete();
    MLookupInfo ml = mField.getLookupInfo();
    ListBoxVO listBoxVO = Util.convertLookupToVO((Lookup)lookupPlan, f_plan.IsMandatoryUI, null);
    ConvertUIVO.copyLookupInfo(listBoxVO, ml);
    f_plan.listBoxVO = listBoxVO;
    searchFields.add(f_plan);
    FieldVO f_period = this.c_info.getComponentVO().getFieldVO("C_Period_ID");
    f_period.listBoxVO = new ListBoxVO();
    if (f_plan.listBoxVO.getOptions() != null && f_plan.listBoxVO.getOptions().size() != 0) {
      int planID = Integer.parseInt(((NamePair)f_plan.listBoxVO.getOptions().get(0)).getID());
      ArrayList<NamePair> values = getPeriodValues(planID);
      for (NamePair a : values)
        f_period.listBoxVO.addOption(a); 
    } 
    FieldVO f_product = this.c_info.getComponentVO().getFieldVO("M_Product_ID");
    String productValidation = "M_Product.IsActive='Y' AND M_Product.IsPlannedItem='Y'";
    f_product.ValidationCode = productValidation;
    FieldVO f_ordertype = this.c_info.getComponentVO().getFieldVO("OrderType");
    ArrayList<ValueNamePair> orderTypeValues = Util.readReference(serverCtx, 508, "AD_Ref_List.IsActive ='Y'");
    f_ordertype.listBoxVO = new ListBoxVO();
    for (int j = 0; j < orderTypeValues.size(); j++)
      f_ordertype.listBoxVO.addOption((NamePair)orderTypeValues.get(j)); 
    for (int i = 0; i < fieldVOs.size(); i++) {
      FieldVO f_info = fieldVOs.get(i);
      if (f_info.isQueryCriteria) {
        FieldVO f = f_info.copySearch();
        f.IsDisplayed = true;
        searchFields.add(f);
      } 
    } 
    ArrayList<FieldVO> processFields = new ArrayList<FieldVO>();
    this.c_search = new SearchComponentImpl(searchFields.<FieldVO>toArray(new FieldVO[0]));
    this.c_process = new SearchComponentImpl(processFields.<FieldVO>toArray(new FieldVO[0]));
    this.c_process.addFieldVO(Util.createFieldVO(serverCtx, "ProcessRows", Msg.translate(serverCtx, "ProcessRows"), 29));
    this.components.add(this.c_search);
    this.components.add(this.c_info);
    this.components.add(this.c_process);
  }
  
  private ArrayList<NamePair> getPeriodValues(int planID) {
    ArrayList<NamePair> values = new ArrayList<NamePair>();
    String SQL = "SELECT C_Period_ID, Name FROM C_Period WHERE C_Period.IsActive='Y' AND C_Period.PeriodType='S'  AND C_Period.C_Year_ID IN (SELECT C_Year_ID FROM C_Year INNER JOIN MRP_Plan ON (MRP_Plan.C_Calendar_ID = C_Year.C_Calendar_ID) AND (MRP_Plan.MRP_Plan_ID = ? )) AND ((C_Period.C_Year_ID * 1000) + C_Period.PeriodNo) BETWEEN (SELECT ((per1.C_Year_ID * 1000) + per1.PeriodNo) FROM C_Period per1 WHERE per1.C_Period_ID = (SELECT MRP_Plan.C_Period_From_ID  FROM MRP_Plan WHERE MRP_Plan.MRP_Plan_ID = ?))  AND  (SELECT ((per2.C_Year_ID * 1000) + per2.PeriodNo)  FROM C_Period per2 WHERE per2.C_Period_ID =  (SELECT MRP_Plan.C_Period_To_ID  FROM MRP_Plan WHERE MRP_Plan.MRP_Plan_ID = ? ))";
    try {
  //    CPreparedStatement cPreparedStatement = DB.prepareStatement(SQL, (Trx)null);
        CPreparedStatement cPreparedStatement = DB.prepareStatement(SQL, null);
      cPreparedStatement.setInt(1, planID);
      cPreparedStatement.setInt(2, planID);
      cPreparedStatement.setInt(3, planID);
      ResultSet rs = cPreparedStatement.executeQuery();
      while (rs.next()) {
        String value = Integer.toString(rs.getInt(1));
        String name = rs.getString(2);
        values.add(new ValueNamePair(value, name));
      } 
      rs.close();
      cPreparedStatement.close();
    } catch (SQLException e) {
      s_log.log(Level.SEVERE, SQL, e);
    } 
    return values;
  }
  
  public ChangeVO processCallback(String sender) {
    ChangeVO changeVO = new ChangeVO();
    if (sender.equals("Process"))
      submitOrderProcess(changeVO, this.serverCtx, this.windowCtx); 
    if (sender.equals("MRP_Plan_ID")) {
      ValueNamePair selectedPlan = (ValueNamePair)this.windowCtx.getSelectedOption("MRP_Plan_ID");
      if (selectedPlan != null && !selectedPlan.getName().equals("")) {
        int planID = Integer.parseInt(selectedPlan.getID());
        changeVO.addChangedDropDown("C_Period_ID", getPeriodValues(planID));
      } 
    } 
    return changeVO;
  }
  
  private void submitOrderProcess(ChangeVO change, Properties ctx, WindowCtx windowCtx) {
//    SysEnv se = SysEnv.get("CMRP");
//    if (se == null || !se.checkLicense()) {
//      change.addError(CLogger.retrieveError().getName());
//      return;
//    } 
    ArrayList<String[]> selectedValues = windowCtx.getSelectedRows(1);
    BigDecimal processRows = (BigDecimal)this.c_process.getFieldValue(windowCtx, "ProcessRows");
    if (selectedValues.size() == 0 && (processRows == null || processRows.signum() == 0)) {
      change.addError("No rows selected and process rows not specified");
      return;
    } 
    if (selectedValues.size() > 0 && processRows != null && processRows.signum() > 0) {
      change.addError("Rows selected and process rows is specified");
      return;
    } 
    Trx trx = Trx.get("ImplementPlanProcess");
    String insertSQL = "INSERT INTO T_MRPPlanImplement (T_MRPPlanImplement_ID, MRP_PlannedOrder_ID, Line) SELECT ?, o.MRP_PlannedOrder_ID, T_MRPPlanImplementLine_Seq.NEXTVAL FROM (";
    ArrayList<Object> params = new ArrayList();
    int paramT_MRPPlanImplement_ID = QueryUtil.getSQLValue(trx.getTrxName(), "SELECT T_MRPPlanImplementID_Seq.NEXTVAL FROM DUAL", new Object[0]);
    
    params.add(Integer.valueOf(paramT_MRPPlanImplement_ID));
    if (selectedValues.size() != 0) {
      insertSQL = insertSQL + "SELECT MRP_PlannedOrder_ID FROM MRP_PlannedOrder WHERE MRP_PlannedOrder_ID  ";
      if (selectedValues.size() > 1) {
        insertSQL = insertSQL + " IN (";
      } else {
        insertSQL = insertSQL + "=";
      } 
      for (int i = 0; i < selectedValues.size(); i++) {
        if (i > 0)
          insertSQL = insertSQL + ","; 
        insertSQL = insertSQL + ((String[])selectedValues.get(i))[7];
      } 
      if (selectedValues.size() > 1)
        insertSQL = insertSQL + ")"; 
      insertSQL = insertSQL + ") o";
    } else {
      insertSQL = insertSQL + "SELECT po.MRP_PlannedOrder_ID ";
      QueryVO queryVO = getQueryVO();
      String componentSQL = this.c_info.getComponentSQL(queryVO, windowCtx, null, null, false, true, -1);
      int beginIndex = componentSQL.indexOf(" FROM ");
      if (beginIndex != -1)
        componentSQL = componentSQL.substring(beginIndex); 
      insertSQL = insertSQL + componentSQL;
      params.addAll(this.c_info.getFixedParameters(ctx, (WindowImplIntf)this, windowCtx));
      params.addAll(TableComponentImpl.getQueryParams(queryVO));
      insertSQL = insertSQL + ") o";
      insertSQL = insertSQL + " WHERE ROWNUM <= ?";
      params.add(processRows);
    } 
    int no = DB.executeUpdate(trx, insertSQL, params.toArray());
    s_log.finest(no + " records inserted for SQL: " + insertSQL);
    trx.commit();
    ArrayList<FieldVO> paramFieldVOs = new ArrayList<FieldVO>(2);
    paramFieldVOs.add(new FieldVO("T_MRPPlanImplement_ID", "T_MRPPlanImplement_ID", 11));
    ProcessInfoVO processInfo = ReportServiceHelper.staticGetProcessInfoByProcessKey("MRP Implement Engine", "D", this.windowNO, ctx);
    processInfo.Parameters = paramFieldVOs;
    HashMap<String, ValueNamePair> parameters = new HashMap<String, ValueNamePair>();
    parameters.put("T_MRPPlanImplement_ID", new ValueNamePair(Integer.toString(paramT_MRPPlanImplement_ID), Integer.toString(paramT_MRPPlanImplement_ID)));
    ReportServiceHelper.startProcess(processInfo, this.serverCtx, parameters);
   
//    if (change.changedFields == null)
//        change.changedFields = new HashMap<Object, Object>(); 
//    change.changedFields.put("isProcess", "Y");
//    change.changedFields.put("isError", processInfo.isError ? "Y" : "N");
//    change.changedFields.put("summary", processInfo.Summary);
//    change.changedFields.put("logInfo", processInfo.logInfo);
    
    if (change.changedFieldsnew == null)
      change.changedFieldsnew = new HashMap<Object, Object>(); 
    change.changedFieldsnew.put("isProcess", "Y");
    change.changedFieldsnew.put("isError", processInfo.isError ? "Y" : "N");
    change.changedFieldsnew.put("summary", processInfo.Summary);
    change.changedFieldsnew.put("logInfo", processInfo.logInfo);
    trx.close();
  }
  
  
  private QueryVO getQueryVO() {
    QueryVO b = TableComponentImpl.buildQueryVO(this.windowCtx, (this.c_info.getComponentVO()).fieldVOs);
    return b;
  }
  
  public final ArrayList<ComponentImplIntf> getComponents() {
    return this.components;
  }
  
  public WindowVO.ClientWindowType getClientWindowType() {
    return WindowVO.ClientWindowType.SELECTION;
    
  }
}

